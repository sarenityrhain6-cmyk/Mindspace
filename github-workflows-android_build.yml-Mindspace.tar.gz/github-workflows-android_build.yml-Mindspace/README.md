# github-workflows-android_build.yml
Mind space is an app to make you more self aware of any mental illness giving everybody the ability to work on themselves especially if they cannot reach out to help immediately in ways they need to
